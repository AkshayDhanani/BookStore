<?php
// Start the session
session_start();
?>

<!DOCTYPE html>
<html>

<head>
<link type="text/css" rel="stylesheet" href="home.css">
<title> Online Bookstore </title>
</head>

<body>
<h1>
<marquee behavior="alternate" id="mov">Welcome to Online BookStore...</marquee>
</h1>
     <header>
<nav>
<ul>    
<li><a href="index.html">Home</a></li>
<li><a href="store.php">Store</a></li>
 <!--                For disable the checkout page option-->
<li class="disabled active"><a href="">Checkout</a></li>

</ul>
</nav>
</header>
    <main>
        <?php 
require('mysqli_connect.php');
$q="select Bookid, Book_name from BookInventory";
$r = @mysqli_query($dbc, $q);
echo "<table><tr> <th>Book Name</th> </tr>";
if (!$dbc) { die('Cannot connect: ' . mysqli_error($dbc) . mysqli_errno($dbc)); }
$checkforrow = mysqli_num_rows($r); 
if($checkforrow>0){
while($row = mysqli_fetch_array($r)) {
    
echo '<tr><td><a href="?run='.$row['Bookid'].'">'.$row['Book_name']."</a></td></tr>";


}
    
}


mysqli_close($dbc);
?>
        <?php 
        
        if(isset($_GET['run'])){
            $id=$_GET['run'];
            sessionFunc($id);
        }
        function sessionFunc($sess_var){
            $_SESSION["Bookname"]=$sess_var;
            header("Location: checkout.php");
        }
?>

    </main>

</body>

</html>