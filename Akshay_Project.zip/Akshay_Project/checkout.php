<?php 

session_start();

?>
<html>

<head>
<link type="text/css" rel="stylesheet" href="home.css">
<title> Online Bookstore </title>
</head>

<body>
<h1>
<marquee behavior="alternate" id="mov">Welcome to Online BookStore...</marquee>
</h1>
    <header>
<nav>
<ul>    
<li><a href="index.html">Home</a></li>
<li><a href="store.php">Store</a></li>
 <!--                For disable the checkout page option-->
<li class="disabled active"><a href="">Checkout</a></li>

</ul>
</nav>
</header>
   
<?php 
            require('mysqli_connect.php');

            if($_SERVER['REQUEST_METHOD'] == 'POST'){
                if(empty($_POST['firstname'])){
                    echo '<p class="alert alert-danger">Please enter First Name</p>';
                }

                if(empty($_POST['lastname'])){
                    echo '<p class="alert alert-danger">Please enter Last Name</p>';
                }

                if(empty($_POST['payment'])){
                    echo '<p class="alert alert-danger">Please select payment way</p>';
                }

                $book="book_name";

                

                if(!empty($_POST['firstname']) && !empty($_POST['lastname']) && !empty($_POST['payment'])){
                    
                    $dbquery = "INSERT INTO Bookinventoryorder(firstname, lastname, payment, BookID) VALUES('".$_POST['firstname']."', '".$_POST['lastname']."', '".$_POST['payment']."', '".$_SESSION['Bookname']."')"; 
            
                    if ($dbc->query($dbquery) === TRUE) {
                        echo "Congratulations , New Order placed. ";
                    } else {
                        echo "Error: " . $dbquery . "<br>" . $dbc->error;
                    }

                    $update = "UPDATE Bookinventory SET quantity = quantity-1 WHERE Bookid=".$_SESSION['Bookname'];
                    if ($dbc->query($update) === TRUE) {
                        
                    } else {
                        echo "Error: " . $update . "<br>" . $dbc->error;
                    }
                }
                
            }
            
            mysqli_close($dbc);

        ?>



           
    <main>

        <?php

            echo "".$_SESSION["Bookname"];
        ?>

        <form action="checkout.php" method="post">
            <table>
                <tr class="form-group">
                    <th class="control-label">First Name:</th>
                    <td></td>
                    <td><input type="text" name="firstname" class="form-control" required></td>
                </tr>
                <tr class="form-group">
                    <th class="control-label">Last Name:</th>
                    <td></td>
                    <td><input type="text" name="lastname" class="form-control" required></td>
                </tr>
                <tr class="form-group">
                    <th class="control-label">Payment way:</th>
                    <td></td>
                    <td> <input list="payment_methods" name="payment" class="form-control" required>
                        <datalist id="payment_methods">
                            <option value="Debit" class="form-control">  
                        </datalist>
                    </td>
                </tr>
                <tr class="form-group">
                    <td></td>
                    <td><input type="Submit" value="Place Order" target="blank"></td>
                    <td></td>
                </tr>
            </table>
        </form>

    </main>
</body>
</html>