CREATE TABLE `mariadb`.`Bookinventory` ( `BookID` INT NOT NULL AUTO_INCREMENT , `Book_name` VARCHAR(30) NOT NULL , `Quantity` INT NOT NULL , PRIMARY KEY (`BookID`)) ENGINE = InnoDB;


CREATE TABLE `mariadb`.`Bookinventoryorder` (firstname varchar(30) , lastname varchar(30), payment varchar(50) , BookID int)