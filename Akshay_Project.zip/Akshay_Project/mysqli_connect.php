<html>
    <head>
        <body>

        <?php
            define('DB_USER','Akshay');
            define('DB_PASSWORD','');
            define('DB_HOST','localhost');
            define('DB_NAME','mariadb');

            $dbc = @mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME) or die ('Could not connect to MySQL:'.
            mysqli_connect_error() );
            
            mysqli_set_charset($dbc, 'utf8');

        ?>

</body>
</head>
</html>